import asyncio
import logging
from telegram.ext import Application, CommandHandler
from config import load_settings
from telegram_app import VeloxTelegram

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
)
log = logging.getLogger("velox_quantum")

async def post_init(application: Application):
    app = application.bot_data["velox"]
    await app.initialize()

async def post_shutdown(application: Application):
    app = application.bot_data.get("velox")
    if app:
        await app.shutdown()

def main():
    settings = load_settings()
    if not settings.telegram_token:
        raise SystemExit("Missing TELEGRAM_BOT_TOKEN in .env")
    if not settings.allowed_user_ids:
        raise SystemExit("Set ALLOWED_TELEGRAM_USER_IDS to your numeric Telegram user ID.")
    if settings.max_stake <= 0 or settings.default_stake <= 0 or settings.default_stake > settings.max_stake:
        raise SystemExit("Invalid stake settings: require 0 < DEFAULT_STAKE <= MAX_STAKE.")
    application = Application.builder().token(settings.telegram_token).post_init(post_init).post_shutdown(post_shutdown).build()
    controller = VeloxTelegram(settings)
    application.bot_data["velox"] = controller
    for command, handler in [
        ("start", controller.start), ("help", controller.help),
        ("status", controller.status), ("balance", controller.balance),
        ("monitor", controller.monitor), ("stop", controller.stop),
        ("stake", controller.stake), ("duration", controller.duration),
        ("symbol", controller.symbol), ("arm_demo", controller.arm_demo),
        ("arm_real", controller.arm_real), ("disarm", controller.disarm),
    ]:
        application.add_handler(CommandHandler(command, handler))
    log.info("Starting Velox Quantum Telegram bot")
    asyncio.set_event_loop(asyncio.new_event_loop())
    application.run_polling(drop_pending_updates=True)

if __name__ == "__main__":
    main()
